<?php
include('db_config.php');
  $name = $email =$phno ='';
  $errors = array('email'=>'','name'=>'' , 'phno'=>'');
  if(isset($_POST['submit'])){
    if(empty($_POST['email'])){
      $errors['email'] = 'An email is required <br />';
    }
    else {
      $email = $_POST['email'];
      if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $errors['email'] = 'email must be a valid email address';
      }
    }
    if(empty($_POST['name'])){
      $errors['name'] = 'A name is required <br />';
    }
    else {
      $name = $_POST['name'];
      if(!preg_match('/^[a-zA-Z\s]+$/',$name)){
        $errors['name'] = 'enter valid name';
      }
    }
    if(empty($_POST['phno'])){
      $errors['phno'] = 'A phone number is required <br />';
    }
    else {
      $phno=$_POST['phno'];
      if(!preg_match('/^[6-9]\d{9}$/',$phno)){
        $errors['phno'] = 'enter valid phone number';
      }
    }
    if(array_filter($errors)){

    }else {
      $name = mysqli_real_escape_string($conn,$_POST['name']);
      $email = mysqli_real_escape_string($conn,$_POST['email']);
      $phno = mysqli_real_escape_string($conn,$_POST['phno']);

      $sql = "INSERT INTO register(name,email,phone_number) VALUES('$name','$email','$phno')";

      if(mysqli_query($conn,$sql)){
          header('Location: roadie2.php');
      }else {
        echo "query error". mysqli_error($conn);
      }



    }
  }
 ?>



















 <!DOCTYPE html>
   <html lang="en">
     <head>
     <title>Motorcycleblog</title>
     <link href="./roadiecss.css" rel="stylesheet" type="text/css">
     <link href="https://fonts.googleapis.com/css?family=Montserrat|Ubuntu&display=swap" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto+Slab|Ubuntu&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     </head>
     <body>
       <section id="full">
       <nav class="navbar navbar-expand-lg navbar-dark">
         <a class="navbar-brand" href="">MotorHeads</a>
         <ul class="navbar-nav mc-auto">
           <li class="navbar-item">
             <a class="nav-link" href="">Road Tripping</a>
           </li>

           <li class="navbar-item">
             <a class="nav-link" href="">Latest On Track</a>
           </li>
           <li class="navbar-item">
             <a class="nav-link" href="">Ride like A Pro</a>
           </li>
           <li class="navbar-item">
             <a class="nav-link" href="">Rental</a>
           </li>
           <li class="navbar-item">
             <a class="nav-link" href="">Roadie</a>
           </li>
         </ul>
       </nav>
       <div>
         <h1 class="ali">Roadie</h1>
       </div>
     </section>
     <h2 id="sizes">Upcoming Events</h2>
     <section id="pics">
       <!-- <h2>Upcoming Events</h2> -->
       <div class="row">
       <div class="feature-box col-lg-4 zoom">
       <img class="image1" src="C:\Users\Sathvik\Desktop\web tech\way1.jpg">
       <h3>Wayanad Meetup</h3>
       <button onclick="document.getElementById('myForm').style.display='block'" type="button" class="btn btn-warning btn-lg reg" style="width: auto">Register</button>
       </div>

       <div class="feature-box col-lg-4 zoom">
         <img class="image2" src="C:\Users\Sathvik\Desktop\web tech\darjeeling-bike-rides.jpg">
       <h3>Tibet Meetup</h3>
       <button onclick="document.getElementById('myForm').style.display='block'" type="button" class="btn btn-warning btn-lg reg" style="width: auto">Register</button>
       </div>

       <div class="feature-box col-lg-4 zoom">
         <img class="image3" src="C:\Users\Sathvik\Desktop\web tech\coorg1.jpg">
       <h3>Coorg Meetup</h3>
       <button onclick="document.getElementById('myForm').style.display='block'" type="button" class="btn btn-warning btn-lg reg" style="width: auto">Register</button>
       </div>
       </div>
       <div class="modal" id="myForm">
           <span onclick="document.getElementById('myForm').style.display='none'" class="close" title="Close Modal">&times;</span>

           <form class="modal-content" action="roadie.php" method="POST">
             <h1>Register</h1>
           <div class="pad">
             <label for="name"><b>Name</b></label>
             <input type="text" placeholder="Enter Name" name="name" value="<?php echo htmlspecialchars($name) ?>">
             <div class="red-text"><?php echo $errors['name'];?></div>
           </div>

           <div class="pad">
             <label for="email"><b>Email</b></label>
             <input type="text" placeholder="Enter Email" name="email" value="<?php echo htmlspecialchars($email) ?>">
             <div class="red-text"><?php echo $errors['email'];?></div>
           </div>

           <div class="pad">
             <label for="phno"><b>Mobile number</b></label>
             <input type="text" placeholder="Enter Mobile Number" name="phno" value="<?php echo htmlspecialchars($phno) ?>">
             <div class="red-text"><?php echo $errors['phno'];?></div>
           </div>

           <div class="pad">
             <button type="submit" class="btn btn-primary" name="submit" value="submit">Submit</button>

           </div>
           </form>
         </div>
     </section>

     <h2 id="sizes">Completed Events</h2>
     <section id="pics">

         <div class="row">
         <div class="feature-box col-lg-4 zoom">
           <!-- <a href="htgallery.html"> -->
         <img class="image1 win" src="C:\Users\Sathvik\Desktop\web tech\darjeeling\dar5.jpg">
          </a>
         <h3>Darjeeling Meetup</h3>
         <!-- <button onclick="document.getElementById('myForm').style.display='block'" type="button" class="btn btn-warning btn-lg reg" style="width: auto">Register</button> -->
         </div>

         <div class="feature-box col-lg-4 zoom">
           <!-- <a href="htgallery.html"> -->
           <img class="image2 win" src="C:\Users\Sathvik\Desktop\web tech\kodai\ko5.jpg">
           </a>
         <h3>Kodaikanal Meetup</h3>
         <!-- <button onclick="document.getElementById('myForm').style.display='block'" type="button" class="btn btn-warning btn-lg reg" style="width: auto">Register</button> -->
         </div>

         <div class="feature-box col-lg-4 zoom">
           <!-- <a href="htgallery.html"> -->
           <img class="image1 win" src="C:\Users\Sathvik\Desktop\web tech\himalaya\him6.jpg">
           </a>
         <h3>Ladakh Meetup</h3>
         <!-- <button onclick="document.getElementById('myForm').style.display='block'" type="button" class="btn btn-warning btn-lg reg" style="width: auto">Register</button> -->
         </div>
         </div>

       </section>




     <script src="D:\sathvik\webtech\roadie.js" charset="utf-8"></script>
     </body>
   </html>
