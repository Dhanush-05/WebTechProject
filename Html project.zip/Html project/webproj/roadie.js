var x=document.querySelectorAll(".win").length;
for(var i=0 ;i<x; i++)
{
    document.querySelectorAll(".win")[i].addEventListener("click",function () {
        window.open("htgallery.html");
    // x.addEventListener[i]("click",function () {
    //     document.getElementById("myForm").style.display = "block";
    // })
}

// var y=document.getElementsByClassName("btn")
// for(var i;i<y.length;i++)
// {
//     y.addEventListener[i]("click",function () {
//         document.getElementById("myForm").style.display = "none";
//     })
// }
// window.onclick = function(event) {
//     if (event.target == x) {
//         x.style.display = "none";
//     }
// }
for(var j=0; j<x ; j++)
{
    document.getElementsByClassName(".close")[i].addEventListener("click",function () {
        document.getElementById('#myForm').style.display='none';
    }
}
