<?php
$valid_name=$valid_email=false;
$con=mysql_connect('127.0.0.1','Dhanush','');
if($con)
{
    echo'Not connected to Server';
}

if(!mysql_select_db($con,'form_validation')
{
    echo'Database not selected';
}

   
   
   
$nameProb = $emailProb = "";
$name = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameProb = "Please enter a Name";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameProb = "Only letters and white space allowed";
            
    }
    else
    $GLOBALS['valid_name']=true;  
  }
  
  if (empty($_POST["email"])) {
    $emailProb = "Please enter email-id";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailProb= "Invalid email, please try again";
    }
    else $GLOBALS['valid_email']=true;  
  }
}

if($valid_email && $valid_name)
   {
       $sql="INSERT INTO form_validation(Name,Email) VALUES('$name','$email') ";
   }
   
/*if(!mysqli_query($con,$sql))
{
    echo 'Not inserted';
}
else echo'Inserted'*/  
header("refresh:1; url="C:/Users/Dhanush/Desktop/Html project/story.html");   
   
   function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
   








?>