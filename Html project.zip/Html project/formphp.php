<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;
        }

form {
  border: 2px solid black;
  font-family: monospace;
}

.container {
  padding: 20px;
  background-color:darkgrey;
  ;
    
  
}

input[type=text], input[type=submit],input[type=email] {
  width: 100%;
  padding: 12px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

input[type=checkbox] {
  margin-top: 16px;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  border: none;
}

input[type=submit]:hover {
  opacity: 0.8;
}

    h2{
        font-family: cursive;
        font-size:40px;
        color:black;
        font-style: oblique;
        font-weight: 400;
    }
    p{
        font-family: monospace;
        font-size:40px;
        
        
    }
    .errorMessage{
        color:brown;
        font-display: block;
    }
</style>
<body>

<?php
$nameProb = $emailProb = "";
$name = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Please enter a Name";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Please enter email-id";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email, please try again";
    }
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
    
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div class="container">
    <h2>Subscribe to our Newsletter</h2>
      <p><b>Get the latest news from the world of motorycles!</b></p>
  </div>

  <div class="container" style="background-color:ghostwhite">
    <input type="text" placeholder="Name" name="name" >
      <span class="errorMessage">* <?php echo $nameProb;?></span>
  <br><br>
    
    <input type="text" placeholder="Email address" name="email">
      <span class="errorMessage">* <?php echo $emailProb;?></span>
  <br><br>
    <label>
      <input type="checkbox" checked="checked" name="subscribe"> Daily Newsletter
    </label>
  </div>

  <div class="container">
    <button style="padding: 0;border: none;background: none;" ><input type="submit" value="Subscribe"></button>
    <button style="padding: 0;border: none;background: none;" onclick="window.open('./story.html')"><input type="submit" value="No thanks,I'm okay!"></button>
  </div>
</form>

</body>
</html>
