<?php

$conn= mysqli_connect('localhost','motorheads','6666','motorheads');
if(!$conn)
{
  echo 'Connection error:'. mysqli_connect_error();
}

 ?>
